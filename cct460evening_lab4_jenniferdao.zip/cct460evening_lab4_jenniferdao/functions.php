<?php
function cd_child_entheme_enqueue_scripts ()
	{
		wp_enqueue_style ('parent-css', get_template_directory_uri ().'/style.css'); 
	} 
add_action('wp_enqueue_scripts','cd_child_entheme_enqueue_scripts');
// This to is to add action for the first sidebar
add_action( 'widgets_init', 'cd_child_widgets_init');
function cd_child_widgets_init (){
		register_sidebar(array(
			'name'						=> __('Sidebar','jenniferanhdao'),
			'id'						=> 'the_sidebar',
			'before_widget'				=> '<aside id="%1$s" class="widget %2$s">',
			'after_widget'				=> '</aside>',
			'before_title'				=> '<h1 class="widget-title">',
			'after_title'				=> '</h1>',
		));
}
add_filter('the_content','add_signature');
function add_signature($text){
global $post;
if($post->post_type=='post')$text.='<div class="signature">
<img src="http://phoenix.sheridanc.on.ca/~ccit3430/wp-content/themes/jd_fluffychildtheme/images/signaturetagline.png"alt="signature"/>
</div>';
return $text;
}
//Retrieved from course lecture slides 
global $more;
$more = 0;
?>
<?php
add_filter( 'the_content_more_link', 'modify_read_more_link' );
function modify_read_more_link() {
return '<a class="more-link" href="' . get_permalink() . '">...to keep on reading.</a>';
}
// Gravatar that is customized 
add_filter( 'avatar_defaults', 'newgravatar' );
function newgravatar ($avatar_defaults) {
$myavatar = get_bloginfo('template_directory') . '/images/cupcake.png';
$avatar_defaults[$myavatar] = "";
return $avatar_defaults;
}
function cd_posts_navigation() {
// Don't print empty markup if there's only one page.
if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
return;
}
?>
<nav class="navigation posts-navigation" role="navigation">
<h2 class="screen-reader-text"><?php _e( 'Posts navigation', 'jenniferanhdao' ); ?></h2>
<div class="nav-links">

<div class="nav-previous"><?php next_posts_link(__( '&larr; Lets Go Back A Page!', 'jenniferanhdao' ) ); ?></div>

<div class="nav-next"><?php previous_posts_link( __( 'Lets Go Forward A Page! &rarr;', 'jenniferanhdao' )  ); ?></div>
</div><!-- .nav-links -->
</nav><!-- .navigation -->
<?php
}
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 10, 10);
?>