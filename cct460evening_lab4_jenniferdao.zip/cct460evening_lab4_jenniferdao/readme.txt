Student:	Jennifer Dao

Course:		CCT460 Evening session

Lab:		Lab #4 - Responsive web layout

Phoenix:	http://phoenix.sheridanc.on.ca/~ccit3430/

