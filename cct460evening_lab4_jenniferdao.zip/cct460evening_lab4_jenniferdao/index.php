<?php
/**
* Template for index page. 
*
* @package Fluffy
*/

get_header(); ?>
<div id="primary" class="content-area">
<main id="main" class="site-main" role="main">
<div id="gridcontainer">
<?php 
	$counter = 1; 
	$grids = 2; 
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$args = array('posts_per_page' => 5, 'paged' => $paged, 'cat'=>30 );

query_posts( 'category_name=Markup&posts_per_page=5&paged=' . $paged ); 
if(have_posts()) :  while(have_posts()) :  the_post();
?>

<?php
if($counter == 1) :
?>

<div class="griditemleft">
<div class="postimage">
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('category-thumbnail'); ?></a>
</div>

<h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</div>

<?php
elseif($counter == $grids) :?>
	<div class="griditemright">
	<div class="postimage">

<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('category-thumbnail'); ?></a>
</div>

<h2><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
</div>
<div class="clear"></div>

<?php
$counter = 0;
endif;
?>

<?php
$counter++;
endwhile; ?>
<?php the_posts_pagination( $args ); ?>

<?php endif;
?>
</div>
</main><!-- #main -->
</div><!-- #primary -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>