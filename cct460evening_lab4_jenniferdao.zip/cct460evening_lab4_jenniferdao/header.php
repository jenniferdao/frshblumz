<?php
/**
 * The header for our theme.
 *
 * @package Fluffy
 */
?><!DOCTYPE html>
<html 
<?php language_attributes(); ?>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<!-- Allows for the viewing to fit accordingly to the device width, thus responsive -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php 
// Connects the functions, stylesheet, menu, and additional features in the wp_head
	wp_head(); 
?>
</head>

<body <?php body_class(); ?>
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Move to 		content', 'jenniferanhdao' ); ?></a>

	<nav id="site-navigation" class="main-navigation" role="navigation">
			<?php if ( has_nav_menu( 'social' ) ) {
				wp_nav_menu(
					array(
						'theme_location'  => 'social',
						'container'       => 'div',
						'container_id'    => 'menu-social',
						'container_class' => 'menu',
						'depth'           => 1,
						'menu_id'         => 'menu-social-items',
						'menu_class'      => 'menu-items',
						'link_before'     => '<span class="screen-reader-text">',
						'link_after'      => '</span>',
						'fallback_cb'     => '',
					)
				);			
			} ?>
	<!-- Hamburger menu that appears when resolution size is at a certain px and shows 		three lines -->
	<button class="menu-toggle" aria-controls="primary" aria-expanded="false">
			<span class="menu-text">		</span>
			<span class="hamburger-line">	</span>
			<span class="hamburger-line"> 	</span>
			<span class="hamburger-line"> 	</span>
		<!-- The hamburger menu text name that appears -->
			<?php esc_html_e( 'Menu', 'jenniferanhdao' ); ?></span></button>
			
			<?php wp_nav_menu( 
				array(
					'theme_location'  => 'primary',
					'container'       => 'div',
					'container_id'    => 'menu-main',
					'container_class' => 'menu',
					'menu_id'         => 'menu-main-items',
					'menu_class'      => 'menu-items',
					) 
				); 
			?>			
		</nav>
<!-- Calls the master header styling that is from the child theme to appear -->
<header id="masthead" class="site-header" role="banner">
	<div class="site-branding container">
        	<?php if (get_header_image() != '') { ?>
				<img src="<?php echo header_image(); ?>" height="<?php echo get_custom_header()->height; ?>" width="<?php echo get_custom_header()->width; ?>" alt="<?php get_bloginfo('name'); ?>" />
            <?php } else { ?>
            	<!-- When the h1 title is clicked it automatically loads website to landing page -->
            	<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
            <?php bloginfo( 'name' ); ?></a></h1>
				<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
            <?php } ?>
		</div><!-- .site-branding -->
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

<!-- Will only appear on mobile viewing mode -->
<div id="content" class="site-content container">
	<?php if (wp_is_mobile()){ 
	echo '<section class="mobile-only">Mobile friendly version.</section>';
	} ?>